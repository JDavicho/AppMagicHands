package com.example.discapacidadauditiva

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button

class Cam : AppCompatActivity(), View.OnClickListener {

    private var txt: Button? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cam)
        txt= findViewById(R.id.txt) as Button
        txt!!.setOnClickListener(this)
    }

    override fun onClick(p0: View?) {
        val lanzar = Intent(this, Texto::class.java)
        startActivity(lanzar)
    }
}