package com.example.discapacidadauditiva

import android.app.Activity
import android.app.Instrumentation
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Camera
import android.os.Build
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.RecognizerResultsIntent
import android.speech.SpeechRecognizer
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.widget.*
import androidx.activity.result.ActivityResult
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.accessibility.AccessibilityEventCompat.setAction
import androidx.viewpager.widget.ViewPager
import com.bumptech.glide.Glide
import com.example.discapacidadauditiva.databinding.ActivityMainBinding
import com.google.android.material.tabs.TabLayout
import com.google.firebase.storage.FirebaseStorage
import pl.droidsonroids.gif.GifAnimationMetaData
import java.io.File
import java.util.*
import kotlin.collections.ArrayList
import java.io.File.createTempFile as createTempFile1

class Texto : AppCompatActivity(), View.OnClickListener, TextWatcher {


    lateinit var binding: ActivityMainBinding
    lateinit var activityResultLauncher: ActivityResultLauncher<Intent>
    private var tabla: TableLayout?=null
    private var traductor: Button? = null
    private var log: Button? = null
    private var ingre: EditText? = null
    private var view: ViewPager?= null
    private var img: ImageView? = null
    private var Inic: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_loguin2)



        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)


        ingre = findViewById(R.id.editTextText) as EditText
        img = findViewById(R.id.imageView3) as ImageView
        /*plbr = findViewById(R.id.palabra) as TextView*/
        traductor = findViewById(R.id.tradu) as Button
        traductor!!.setOnClickListener(this)

        binding.came.setOnClickListener(){
            val lanzar = Intent(this, Cam::class.java)
            startActivity(lanzar)
        }












/*  Traduce y manda a llamar la imagen por medio del Audio*/
        binding.audi.setOnClickListener() {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            intent.putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Traduciendo..")
            try {
                activityResultLauncher.launch(intent)
            } catch (exp: ActivityNotFoundException) {
                Toast.makeText(applicationContext, "Device does supported", Toast.LENGTH_SHORT).show()

            }

        }
        /*Muestra la pantalla del microfono de Google*/
        activityResultLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {result: ActivityResult? ->
            if (result!!.resultCode == RESULT_OK && result!!.data != null){
                val spechtext= result!!.data!!.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)as ArrayList<Editable>
                binding.editTextText.text=spechtext[0]

                val imageName = binding.editTextText.text.toString()
                val storageRef =
                    FirebaseStorage.getInstance().reference.child("/Images/$imageName.gif")

                val localfile = File.createTempFile("tempImage", "anim")
                storageRef.getFile(localfile).addOnSuccessListener {

                    val bitmap = BitmapFactory.decodeFile(localfile.absolutePath)
                    binding.gifImageView2.setImageBitmap(bitmap)



                }.addOnFailureListener {
                    Toast.makeText(this, "Error, Traducción No Encontrada", Toast.LENGTH_SHORT)
                        .show()
                }
            }



        }


    }

    override fun onClick(p0: View?) {
        traduccion()

    }
/* Funcion que traduce y manda a llamar la imagen por medio de el boton*/
        private fun traduccion() {


            Inic = ingre?.text.toString()


            binding.tradu.setOnClickListener() {
                val imageName = binding.editTextText.text.toString()
                val storageRef =
                    FirebaseStorage.getInstance().reference.child("/Images/$imageName.gif")
                val localfile = File.createTempFile("tempImage", "anim")
                storageRef.getFile(localfile).addOnSuccessListener {

                    val bitmap = BitmapFactory.decodeFile(localfile.absolutePath)
                    binding.gifImageView2.setImageBitmap(bitmap)


                }.addOnFailureListener {
                    Toast.makeText(this, "Error, Traducción No Encontrada", Toast.LENGTH_SHORT)
                        .show()
                }

            }

        }

        override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

        }

        override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

        }

        override fun afterTextChanged(p0: Editable?) {

        }
    }


