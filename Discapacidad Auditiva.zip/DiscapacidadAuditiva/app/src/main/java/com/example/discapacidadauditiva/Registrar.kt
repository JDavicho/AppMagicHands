package com.example.discapacidadauditiva

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth

class Registrar : AppCompatActivity(), View.OnClickListener {
    private var reg:Button?=null
    private var email:EditText?=null
    private var pass:EditText?=null
    val ref = FirebaseAuth.getInstance()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registrar)
        reg = findViewById(R.id.regi) as Button
        reg!!.setOnClickListener(this)
        email = findViewById(R.id.email)as EditText
        pass = findViewById(R.id.pas) as EditText

    }

    override fun onClick(p0: View?) {
        ref.createUserWithEmailAndPassword(
            email?.text.toString().trim(),
            pass?.text.toString().trim()
        )

        Toast.makeText(applicationContext, "Usuario registrado correctamente", Toast.LENGTH_SHORT).show()
        val lanzar = Intent(this, Loguin2::class.java)
        startActivity(lanzar)
    }
}