package com.example.discapacidadauditiva

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import com.google.android.material.textfield.TextInputEditText
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.ktx.Firebase

class Loguin2 : AppCompatActivity(), View.OnClickListener {
    private var ini: Button? = null
    private var reg: Button? = null
    private var email:EditText?=null
    private var pass:EditText?=null

    val ref = FirebaseAuth.getInstance()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_loguin2)

        ini = findViewById(R.id.ini) as Button
        ini!!.setOnClickListener(this)
        reg = findViewById(R.id.Reg) as Button
        reg!!.setOnClickListener(clickListener2)

        email = findViewById(R.id.editTextEmail)as EditText
        pass = findViewById(R.id.editTextTextPassword) as EditText






    }

    val clickListener2 = View.OnClickListener {

        val lanzar = Intent(this, Registrar::class.java)
        startActivity(lanzar)
    }


    override fun onClick(p0: View?) {


        val lanzar = Intent(this, Texto::class.java)
        startActivity(lanzar)
    }
    }
